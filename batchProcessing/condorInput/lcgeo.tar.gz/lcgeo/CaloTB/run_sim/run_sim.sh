ddsim --steeringFile ddsim_steering_00.py
